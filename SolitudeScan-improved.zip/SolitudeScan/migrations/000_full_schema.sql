-- ============================================================
-- SolitudeScan — Schema completo (base)
-- Execute este arquivo PRIMEIRO no SQL Editor do Supabase
-- Depois execute os outros migrations de hardening
-- ============================================================

-- Extensões
create extension if not exists "pgcrypto";

-- ============================================================
-- GENRES
-- ============================================================
create table if not exists public.genres (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  created_at timestamptz not null default now()
);

-- ============================================================
-- WORKS (obras)
-- ============================================================
create table if not exists public.works (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  cover_url text,
  author text default 'Desconhecido',
  artist text,
  status text not null default 'Em Lançamento'
    check (status in ('Em Lançamento', 'Completo', 'Hiato')),
  type text not null default 'Manhwa'
    check (type in ('Manhwa', 'Manga', 'Manhua', 'Webtoon', 'Outro')),
  synopsis text default '',
  views bigint not null default 0,
  likes_count bigint not null default 0,
  rating_avg numeric(3,2) not null default 0,
  rating_count integer not null default 0,
  is_featured boolean not null default false,
  is_vip boolean not null default false,
  is_adult boolean not null default false,
  is_published boolean not null default true,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists works_published_idx on public.works (is_published, deleted_at, updated_at desc);
create index if not exists works_featured_idx on public.works (is_featured) where is_featured = true;
create index if not exists works_slug_idx on public.works (slug);

-- ============================================================
-- WORK_GENRES (relação N:N)
-- ============================================================
create table if not exists public.work_genres (
  work_id uuid not null references public.works(id) on delete cascade,
  genre_id uuid not null references public.genres(id) on delete cascade,
  primary key (work_id, genre_id)
);

-- ============================================================
-- CHAPTERS
-- ============================================================
create table if not exists public.chapters (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.works(id) on delete cascade,
  chapter_number numeric(10,2) not null,
  title text,
  is_published boolean not null default true,
  is_vip boolean not null default false,
  views bigint not null default 0,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (work_id, chapter_number)
);

create index if not exists chapters_work_idx on public.chapters (work_id, chapter_number);

-- ============================================================
-- PAGES
-- ============================================================
create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  chapter_id uuid not null references public.chapters(id) on delete cascade,
  page_number integer not null,
  image_url text not null, -- path no storage bucket 'chapters'
  created_at timestamptz not null default now(),
  unique (chapter_id, page_number)
);

create index if not exists pages_chapter_idx on public.pages (chapter_id, page_number);

-- ============================================================
-- PROFILES
-- ============================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  email text,
  avatar_url text,
  phone text,
  is_admin boolean not null default false,
  role text not null default 'user',
  is_vip boolean not null default false,
  vip_plan text,
  vip_expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============================================================
-- FAVORITES
-- ============================================================
create table if not exists public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  work_id uuid not null references public.works(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, work_id)
);

-- ============================================================
-- RATINGS
-- ============================================================
create table if not exists public.ratings (
  user_id uuid not null references public.profiles(id) on delete cascade,
  work_id uuid not null references public.works(id) on delete cascade,
  score smallint not null check (score between 1 and 5),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id, work_id)
);

-- ============================================================
-- COMMENTS
-- ============================================================
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  work_id uuid not null references public.works(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  parent_id uuid references public.comments(id) on delete cascade,
  is_spoiler boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists comments_work_idx on public.comments (work_id, created_at desc);

-- ============================================================
-- LIKES (comentários e outros)
-- ============================================================
create table if not exists public.likes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('comment', 'work')),
  target_id uuid not null,
  created_at timestamptz not null default now(),
  unique (user_id, target_type, target_id)
);

-- ============================================================
-- REPORTS
-- ============================================================
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete set null,
  target_type text not null,
  target_id uuid not null,
  reason text,
  status text not null default 'pending'
    check (status in ('pending', 'resolved', 'dismissed')),
  created_at timestamptz not null default now(),
  resolved_at timestamptz
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null default 'info',
  title text not null,
  body text,
  link text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on public.notifications (user_id, is_read, created_at desc);

-- ============================================================
-- USER LISTS
-- ============================================================
create table if not exists public.user_lists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  is_public boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_list_items (
  list_id uuid not null references public.user_lists(id) on delete cascade,
  work_id uuid not null references public.works(id) on delete cascade,
  position integer not null default 0,
  primary key (list_id, work_id)
);

-- ============================================================
-- PAYMENT REQUESTS (PIX)
-- ============================================================
create table if not exists public.payment_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  email text,
  plan text not null,
  amount numeric(10,2) not null,
  status text not null default 'pendente'
    check (status in ('pendente', 'aguardando_confirmacao', 'aprovado', 'rejeitado', 'expirado')),
  pix_key text,
  proof_url text,
  confirmed_at timestamptz,
  rejected_at timestamptz,
  created_at timestamptz not null default now(),
  expires_at timestamptz
);

-- ============================================================
-- ACCOUNT DELETION
-- ============================================================
create table if not exists public.account_deletion_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  requested_at timestamptz not null default now(),
  status text not null default 'pending'
    check (status in ('pending', 'processing', 'completed', 'cancelled')),
  processed_at timestamptz,
  created_at timestamptz not null default now()
);

-- ============================================================
-- TRIGGERS básicos
-- ============================================================
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists works_updated_at on public.works;
create trigger works_updated_at before update on public.works
  for each row execute function public.set_updated_at();

drop trigger if exists chapters_updated_at on public.chapters;
create trigger chapters_updated_at before update on public.chapters
  for each row execute function public.set_updated_at();

-- ============================================================
-- STORAGE BUCKETS (execute no dashboard ou via API)
-- covers  → public
-- chapters → private (signed URLs)
-- avatars  → public
-- ============================================================
