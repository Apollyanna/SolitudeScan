-- ============================================================
-- SolitudeScan — Dados de demonstração
-- Execute DEPOIS do schema e das migrations de segurança
-- ============================================================

-- Gêneros
insert into public.genres (name, slug) values
  ('Ação', 'acao'),
  ('Aventura', 'aventura'),
  ('Romance', 'romance'),
  ('Drama', 'drama'),
  ('Fantasia', 'fantasia'),
  ('Comédia', 'comedia'),
  ('Horror', 'horror'),
  ('Slice of Life', 'slice-of-life'),
  ('Sobrenatural', 'sobrenatural'),
  ('Esportes', 'esportes'),
  ('Sci-Fi', 'sci-fi'),
  ('Mistério', 'misterio')
on conflict (slug) do nothing;

-- Obras de demonstração (capas placeholder — substitua pelas reais depois)
insert into public.works (
  id, title, slug, cover_url, author, artist, status, type, synopsis,
  views, likes_count, rating_avg, rating_count,
  is_featured, is_vip, is_adult, is_published, updated_at
) values
(
  'a1000000-0000-4000-8000-000000000001',
  'Sombras do Eclipse',
  'sombras-do-eclipse',
  'https://placehold.co/300x450/1a0f1e/ec4899?text=Sombras+do+Eclipse',
  'Kim Hyeon',
  'Park Min',
  'Em Lançamento',
  'Manhwa',
  'Em um mundo onde o sol desapareceu, um jovem descobre que carrega o último fragmento de luz. Perseguido por facções que desejam controlar o poder, ele precisa escolher entre salvar a humanidade ou destruí-la.',
  12840, 892, 4.70, 210,
  true, false, false, true, now() - interval '2 hours'
),
(
  'a1000000-0000-4000-8000-000000000002',
  'Coração de Aço',
  'coracao-de-aco',
  'https://placehold.co/300x450/1a0f1e/ec4899?text=Coracao+de+Aco',
  'Lee Soo-jin',
  'Lee Soo-jin',
  'Em Lançamento',
  'Manhwa',
  'Após perder tudo em uma guerra cibernética, uma mercenária digital recebe um corpo mecânico e uma segunda chance. Mas cada upgrade tem um preço: sua humanidade.',
  9450, 670, 4.50, 155,
  true, false, false, true, now() - interval '5 hours'
),
(
  'a1000000-0000-4000-8000-000000000003',
  'Flor de Inverno',
  'flor-de-inverno',
  'https://placehold.co/300x450/1a0f1e/ec4899?text=Flor+de+Inverno',
  'Han Yuna',
  'Choi Ji-eun',
  'Completo',
  'Manhwa',
  'Uma herdeira de uma família tradicional se apaixona por um artista de rua. Entre tradições milenares e o caos da modernidade, o amor floresce no inverno mais frio de Seul.',
  22100, 1540, 4.90, 420,
  true, false, false, true, now() - interval '1 day'
),
(
  'a1000000-0000-4000-8000-000000000004',
  'Reino das Cinzas',
  'reino-das-cinzas',
  'https://placehold.co/300x450/1a0f1e/ec4899?text=Reino+das+Cinzas',
  'Jung Tae',
  'Jung Tae',
  'Em Lançamento',
  'Manhwa',
  'O império caiu. Restaram apenas cinzas e um príncipe que não queria o trono. Agora, ele precisa reunir os últimos guerreiros para impedir que o vazio consuma o que sobrou do mundo.',
  18700, 1100, 4.60, 280,
  false, true, false, true, now() - interval '3 hours'
),
(
  'a1000000-0000-4000-8000-000000000005',
  'Noite Infinita',
  'noite-infinita',
  'https://placehold.co/300x450/1a0f1e/ec4899?text=Noite+Infinita',
  'Sato Aya',
  'Sato Aya',
  'Hiato',
  'Manga',
  'Uma estudante transferida descobre que sua nova cidade nunca amanhece. Os habitantes fingem normalidade, mas algo antigo habita as sombras eternos.',
  6300, 410, 4.30, 98,
  false, false, false, true, now() - interval '7 days'
),
(
  'a1000000-0000-4000-8000-000000000006',
  'Velocidade Máxima',
  'velocidade-maxima',
  'https://placehold.co/300x450/1a0f1e/ec4899?text=Velocidade+Maxima',
  'Ryo Takahashi',
  'Ryo Takahashi',
  'Em Lançamento',
  'Manga',
  'Em corridas ilegais nas montanhas de Tóquio, um piloto amador desafia o rei das ruas. Cada curva pode ser a última.',
  11200, 780, 4.40, 190,
  false, false, false, true, now() - interval '12 hours'
)
on conflict (id) do nothing;

-- Associar gêneros
insert into public.work_genres (work_id, genre_id)
select w.id, g.id
from public.works w
cross join public.genres g
where
  (w.slug = 'sombras-do-eclipse' and g.slug in ('acao', 'fantasia', 'aventura'))
  or (w.slug = 'coracao-de-aco' and g.slug in ('acao', 'sci-fi', 'drama'))
  or (w.slug = 'flor-de-inverno' and g.slug in ('romance', 'drama', 'slice-of-life'))
  or (w.slug = 'reino-das-cinzas' and g.slug in ('acao', 'fantasia', 'aventura'))
  or (w.slug = 'noite-infinita' and g.slug in ('horror', 'misterio', 'sobrenatural'))
  or (w.slug = 'velocidade-maxima' and g.slug in ('acao', 'esportes', 'drama'))
on conflict do nothing;

-- Capítulos de demonstração (sem páginas de imagem reais — você sobe depois pelo admin)
insert into public.chapters (id, work_id, chapter_number, title, is_published, is_vip, published_at, created_at)
select
  gen_random_uuid(),
  w.id,
  n,
  'Capítulo ' || n,
  true,
  (n > 3 and w.slug = 'reino-das-cinzas'), -- últimos caps VIP na obra VIP
  now() - ((10 - n) || ' hours')::interval,
  now() - ((10 - n) || ' hours')::interval
from public.works w
cross join generate_series(1, 5) as n
where w.slug in (
  'sombras-do-eclipse',
  'coracao-de-aco',
  'flor-de-inverno',
  'reino-das-cinzas',
  'noite-infinita',
  'velocidade-maxima'
)
on conflict (work_id, chapter_number) do nothing;

-- Nota: as páginas (imagens) devem ser enviadas pelo painel Admin → Capítulos → Upload de páginas.
-- O seed cria apenas a estrutura de obras e capítulos para o site já mostrar conteúdo.

select 'Seed de demonstração aplicado com sucesso!' as status;
