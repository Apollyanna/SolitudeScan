# SolitudeScan

Plataforma profissional de leitura de **Manhwas, Mangás e Manhuás** online.

Site oficial: [solitudescan.com](https://solitudescan.com) (em construção)

## Características

- Experiência de leitura em cascata (estilo Webtoon) com zoom e modo imersivo
- Catálogo com filtros por gênero, status e ordenação
- Sistema de contas com favoritos, histórico e listas personalizadas
- Planos VIP com capítulos antecipados e leitura sem anúncios (pagamento via PIX)
- Painel administrativo completo (obras, capítulos, usuários, pagamentos, denúncias)
- PWA instalável (funciona como app no celular)
- Design moderno dark/light, responsivo e acessível
- Segurança com Supabase (RLS, signed URLs para páginas, proteção de campos privilegiados)

## Stack

- **Frontend**: HTML5 + CSS3 + JavaScript vanilla (sem framework pesado)
- **Backend**: Supabase (Auth, Database, Storage)
- **PWA**: Service Worker + Web Manifest
- **Hospedagem recomendada**: Cloudflare Pages, Netlify ou Vercel

## Estrutura do projeto

```
/
├── index.html          # Página principal (SPA)
├── style.css           # Estilos
├── script.js           # Toda a lógica da aplicação
├── sw.js               # Service Worker
├── manifest.webmanifest
├── icon.svg / icon-*.png
├── 404.html
├── _headers            # Headers de segurança (Cloudflare/Netlify)
├── robots.txt
├── sitemap.xml
└── migrations/         # SQL de schema e hardening do Supabase
```

## Como rodar localmente

```bash
# Clone
git clone https://github.com/Apollyanna/SolitudeScan.git
cd SolitudeScan

# Servidor simples
python3 -m http.server 8080
# ou
npx serve .
```

Abra `http://localhost:8080`

> **Nota**: O catálogo depende do projeto Supabase configurado. Sem dados no banco, a tela inicial aparece vazia (é normal).

## Configuração do Supabase

1. Crie um projeto no [Supabase](https://supabase.com)
2. Execute os arquivos em `migrations/` na ordem
3. Configure as tabelas principais: `works`, `chapters`, `chapter_pages`, `profiles`, `payment_requests`, etc.
4. Crie os buckets de Storage: `chapters` (privado) e `avatars` (público)
5. Atualize as constantes `SUPABASE_URL` e `SUPABASE_ANON_KEY` em `script.js`

## Transformar em App (APK / iOS)

O site já é uma **PWA** completa. Para gerar um APK real:

### Opção 1 – TWA (Trusted Web Activity) – mais simples
- Use [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) ou [PWA Builder](https://www.pwabuilder.com/)
- Gera APK que abre o site em tela cheia com ícone e splash

### Opção 2 – Capacitor (recomendado para mais controle)
```bash
npm init @capacitor/app
npx cap add android
npx cap sync
npx cap open android
```

Depois é só gerar o APK/AAB pelo Android Studio.

## Melhorias recentes

- Ícones otimizados e manifest completo (PWA de alta qualidade)
- Service Worker atualizado (cache-first para assets)
- Skeleton loading no catálogo
- Meta tags de instalação como app (iOS + Android)
- Headers de segurança reforçados

## Roadmap sugerido

- [ ] Popular o banco com obras iniciais
- [ ] Sistema de notificações push (quando houver novos capítulos)
- [ ] Leitor com modo página-a-página além da cascata
- [ ] Comentários com respostas e denúncia
- [ ] Sistema de ranking semanal real
- [ ] Exportação de dados do usuário (LGPD)
- [ ] Deploy oficial + domínio + SSL
- [ ] Geração de APK via TWA/Capacitor

## Licença

Uso privado / projeto pessoal por enquanto.

---

Feito com ❤️ para a comunidade de manhwas.
