# SolitudeScan — Guia: Banco de Dados + APK

## 1. Configurar o Banco (Supabase)

### Ordem de execução no SQL Editor

1. `migrations/000_full_schema.sql` — cria todas as tabelas
2. `migrations/schema.sql` — hardening de segurança
3. `migrations/20260909013000_production_compatibility.sql`
4. `migrations/20260909014000_security_definer_acl.sql`
5. `migrations/seed_demo.sql` — dados de demonstração (6 obras + capítulos)

### Storage (Dashboard → Storage)

Crie 3 buckets:

| Bucket    | Público? | Uso                          |
|-----------|----------|------------------------------|
| `covers`  | Sim      | Capas das obras              |
| `chapters`| Não      | Páginas dos capítulos (signed URLs) |
| `avatars` | Sim      | Fotos de perfil              |

### Políticas de Storage (exemplo para chapters)

No bucket `chapters` (privado):
- SELECT: autenticados + anon (via signed URL)
- INSERT/UPDATE/DELETE: apenas admin

### Tornar-se Admin

Depois de criar sua conta no site:

```sql
update public.profiles
set is_admin = true, role = 'admin'
where email = 'seu-email@exemplo.com';
```

### Popular com páginas reais

1. Entre no site como admin
2. Abra o painel Admin
3. Crie/edite obras
4. Adicione capítulos
5. Faça upload das imagens das páginas

O seed já cria a estrutura de obras e capítulos. As imagens precisam ser enviadas pelo admin (ou via script de upload).

---

## 2. Gerar o APK (duas opções)

### Opção A — PWA Builder / TWA (mais simples)

1. Publique o site em `https://solitudescan.com`
2. Acesse [https://www.pwabuilder.com](https://www.pwabuilder.com)
3. Cole a URL do site
4. Baixe o pacote Android (TWA)
5. Abra no Android Studio e gere o APK/AAB

### Opção B — Capacitor (mais controle)

```bash
# Na pasta do projeto
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init SolitudeScan com.solitudescan.app --web-dir .

# Criar pasta www com os arquivos estáticos
mkdir -p www
cp index.html style.css script.js sw.js manifest.webmanifest *.png *.svg www/
cp -r migrations www/  # opcional

npx cap add android
npx cap sync
npx cap open android
```

No Android Studio:
- Build → Generate Signed Bundle / APK
- Configure keystore
- Gere o AAB para publicar na Play Store

O arquivo `capacitor.config.json` já está pronto no repositório.

---

## 3. Fluxo de teste completo (checklist)

- [ ] Rodar migrations + seed
- [ ] Criar conta de usuário
- [ ] Tornar a conta admin (SQL)
- [ ] Ver obras na home
- [ ] Abrir detalhes de uma obra
- [ ] Favoritar
- [ ] Ler um capítulo (precisa de páginas no storage)
- [ ] Avaliar obra
- [ ] Comentar
- [ ] Assinar VIP (gerar PIX)
- [ ] Aprovar pagamento no admin
- [ ] Verificar que capítulos VIP liberam
- [ ] Instalar como PWA no celular
- [ ] Testar offline parcial

---

## 4. Próximas funções úteis (já estruturadas)

- Notificações de novos capítulos (tabela `notifications` já existe)
- Listas personalizadas (`user_lists`)
- Exportação de dados (LGPD)
- Ranking semanal real

Quando o banco estiver populado, o site já funciona como scan oficial.
